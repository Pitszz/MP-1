import pytest

from random import randint, choice
from utils import Direction, BlockType
from block import Block
from game import Game
from level import Level

# The methods with no return or yielded values are NOT unit tested.
# Exceptions are some methods in the Block class.
# Inner functions are also not unit tested.


def convert_to_blocks(grid: list[list[str]], game: Game) -> list[list[Block]]:
    result = []

    for i in range(len(grid)):
        temp = []
        for j in range(len(grid[0])):
            block = game.level._create_block(grid[i][j], i, j)
            temp.append(block)
        result.append(temp)

    return result


def test_is_inside() -> None:
    # Takes in NEW_ROW, NEW_COL, ROWS, and COLS -> returns a BOOL
    test_grid = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🥚", "🥚", "🧱", "🍳", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🧱", "🥚", "🧱", "🟩", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🥚", "🟩", "🪹", "🪹", "🪹", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🧱", "🧱", "🧱", "🟩", "🟩", "🟩", "🪹", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🪹", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱", "🪹", "🍳", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🍳", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🍳", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    test_game: Game = Game()
    test_game.grid = convert_to_blocks(test_grid, test_game)

    rows, cols = len(test_grid), len(test_grid[0])

    assert test_game.is_inside_grid(2, 1, rows, cols)
    assert test_game.is_inside_grid(4, 1, rows, cols)
    assert test_game.is_inside_grid(1, 0, rows, cols)
    assert not test_game.is_inside_grid(20, 2, rows, cols)
    assert not test_game.is_inside_grid(5, 12, rows, cols)
    assert not test_game.is_inside_grid(10, 10, rows, cols)
    assert not test_game.is_inside_grid(7, 10**8, rows, cols)

    # EDGE CASES

    # ROWS or COLS is 0 (Should evaluate to False since 0 < 0)
    rows, cols = 10, 10
    rows_0, cols_0 = 0, 0

    assert not test_game.is_inside_grid(0, 6, rows_0, cols)
    assert not test_game.is_inside_grid(4, 0, rows, cols_0)
    assert not test_game.is_inside_grid(0, 0, rows_0, cols_0)


def test_is_movable_to() -> None:
    # takes in a BLOCK, returns a BOOL
    is_movable_test = Game()
    # just need a mock object to test this

    neighbor = Block("Egg", "🥚", BlockType.MOVABLE, 0, 0)
    assert not is_movable_test.is_movable_to(neighbor)

    neighbor_2 = Block("Grass", "🟩", BlockType.FLOOR, 0, 0)
    assert is_movable_test.is_movable_to(neighbor_2)

    neighbor_3 = Block("Wall", "🧱", BlockType.IMMOVABLE, 0, 0)
    assert not is_movable_test.is_movable_to(neighbor_3)

    neighbor_4 = Block("Nest", "🪹", BlockType.GOAL, 0, 0)
    assert is_movable_test.is_movable_to(neighbor_4)

    neighbor_5 = Block("Full Nest", "🪺", BlockType.IMMOVABLE,
                       0, 0)
    assert not is_movable_test.is_movable_to(neighbor_5)

    neighbor_6 = Block("Pan", "🍳", BlockType.VOID, 0, 0)
    assert is_movable_test.is_movable_to(neighbor_6)

    neighbor_7 = Block("Hole", " ", BlockType.VOID, 0, 0)
    assert is_movable_test.is_movable_to(neighbor_7)

    # EDGE CASE: Block mismatch
    # Dependent on BlockType, not any other attributes
    neighbor_x = Block("Egg", "🥚", BlockType.FLOOR, 0, 0)
    assert is_movable_test.is_movable_to(neighbor_x)

    neighbor_y = Block("Pan", "🥚", BlockType.MOVABLE, 0, 0)
    assert not is_movable_test.is_movable_to(neighbor_y)

    neighbor_z = Block("Egg", "🪹", BlockType.MOVABLE, 0, 0)
    assert not is_movable_test.is_movable_to(neighbor_z)

    # EDGE CASE: Raises an AttributeError (BlockType nonexistent)
    with pytest.raises(AttributeError):
        neighbor_a = Block("Egg", "🥚", BlockType.FLOORS, 0, 0)
        assert is_movable_test.is_movable_to(neighbor_a)

        neighbor_b = Block("Egg", "🥚", BlockType.CAR, 0, 0)
        assert is_movable_test.is_movable_to(neighbor_b)

        neighbor_c = Block("Egg", "🥚", BlockType.FLAG, 0, 0)
        assert is_movable_test.is_movable_to(neighbor_c)

        neighbor_d = Block("Egg", "🥚", BlockType.TYPE, 0, 0)
        assert is_movable_test.is_movable_to(neighbor_d)


def test_get_eggs_pos() -> None:
    # Tests if movables_positions is filled up correctly.

    # Mock class Object
    m1: Game = Game()

    movables_test_1 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    m1.grid = convert_to_blocks(movables_test_1, m1)
    assert frozenset(m1.level.get_movables_positions(
        m1.grid)) == frozenset([(2, 2), (3, 2)])

    m2: Game = Game()
    movables_test_2 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🥚", "🥚", "🧱", "🍳", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🧱", "🥚", "🧱", "🟩", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🥚", "🟩", "🪹", "🪹", "🪹", "🟩", "🧱"],
        ["🧱", "🟩", "🧱", "🧱", "🧱", "🟩", "🟩", "🪹", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🟩", "🟩", "🟩", "🪹", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱", "🪹", "🍳", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    grid = convert_to_blocks(movables_test_2, m2)
    assert frozenset(m2.level.get_movables_positions(grid)) == frozenset([
        (1, 1), (1, 2), (1, 3), (2, 3), (3, 1), (3, 2)])

    m3: Game = Game()
    movables_test_3 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    m3.grid = convert_to_blocks(movables_test_3, m3)
    assert frozenset(m3.level.get_movables_positions(
        m3.grid)) == frozenset([(1, 5), (1, 6)])

    # No Eggs
    m4: Game = Game()
    movables_test_4 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    m4.grid = convert_to_blocks(movables_test_4, m4)
    assert m4.level.get_movables_positions(m4.grid) == []

    # Edge Case: Empty GRID
    m5: Game = Game()
    movables_test_5 = [[]]
    m5.grid = convert_to_blocks(movables_test_5, m5)
    assert m5.level.get_movables_positions(m5.grid) == []


def test_all_objects_blocked() -> None:
    # Takes in ROWS, COLS and a DIRECTION -> returns a BOOL

    # Moving Right
    g1: Game = Game()

    eggs_blocked_test = [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    g1.grid = convert_to_blocks(eggs_blocked_test, g1)
    rows, cols = len(eggs_blocked_test), len(eggs_blocked_test[0])
    g1.movables_positions = g1.level.get_movables_positions(
        g1.grid)

    assert not g1.all_movables_blocked(
        rows, cols, Direction.RIGHT)

    # Moving Left
    g2: Game = Game()
    eggs_blocked_test_2 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🥚", "🥚", "🧱", "🍳", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🧱", "🥚", "🧱", "🟩", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🥚", "🟩", "🪹", "🪹", "🪹", "🟩", "🧱"],
        ["🧱", "🟩", "🧱", "🧱", "🧱", "🟩", "🟩", "🪹", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🟩", "🟩", "🟩", "🪹", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱", "🪹", "🍳", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g2.grid = convert_to_blocks(eggs_blocked_test_2, g2)
    rows, cols = len(eggs_blocked_test_2), len(eggs_blocked_test_2[0])
    g2.movables_positions = g2.level.get_movables_positions(
        g2.grid)

    assert g2.all_movables_blocked(
        rows, cols, Direction.LEFT)

    # Moving Forward
    g3: Game = Game()
    eggs_blocked_test_3 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g3.grid = convert_to_blocks(eggs_blocked_test_3, g3)
    rows, cols = len(eggs_blocked_test_3), len(eggs_blocked_test_3[0])
    g3.movables_positions = g3.level.get_movables_positions(
        g3.grid)

    assert g3.all_movables_blocked(
        rows, cols, Direction.FORWARD)

    # Moving Backward
    g4: Game = Game()
    eggs_blocked_test_4 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱",
            "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🪹", "🟩", "🟩", "🍳", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🟩", "🥚", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🧱", "🧱", "🪹", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🧱",
            "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🪹",
            "🟩", "🟩", "🟩", "🟩", "🧱", "🧱", "🟩", "🟩", "🧱"],
        ["🧱", "🥚", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🥚", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🧱", "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🧱", "🧱", "🧱", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🟩", "🧱"],
        ["🧱", "🧱", "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🟩", "🧱"],
        ["🧱", "🥚", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🧱", "🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🪹", "🟩", "🟩", "🍳", "🧱", "🧱", "🧱",
            "🧱", "🧱", "🧱", "🟩", "🟩", "🧱", "🧱", "🥚", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱",
            "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g4.grid = convert_to_blocks(eggs_blocked_test_4, g4)
    rows, cols = len(eggs_blocked_test_4), len(eggs_blocked_test_4[0])
    g4.movables_positions = g4.level.get_movables_positions(
        g4.grid)

    assert not g4.all_movables_blocked(
        rows, cols, Direction.BACKWARD)

    # EDGE CASE: Grid passed is empty
    gx: Game = Game()
    eggs_blocked_test_x = [[]]
    gx.grid = convert_to_blocks(eggs_blocked_test, gx)
    rows, cols = len(eggs_blocked_test_x), len(eggs_blocked_test_x[0])
    gx.movables_positions = gx.level.get_movables_positions(
        gx.grid)

    assert gx.all_movables_blocked(
        rows, cols, Direction.LEFT)
    # returns True by technicali


def test_is_end_state() -> None:
    # Takes in a GRID and MOVES -> returns a BOOL

    # No Egg/s Left, No Moves Left
    game = Game()
    assert game.is_end_state(0, [])

    end_state_test_2 = [
        ['🧱', '🧱', '🧱', '🧱'],
        ['🧱', '🟩', '🟩', '🧱'],
        ['🧱', '🟩', '🟩', '🧱'],
        ['🧱', '🧱', '🧱', '🧱']
    ]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_2, game))

    end_state_test_3 = [
        ['🧱', '🧱', '🧱', '🧱'],
        ['🧱', '🪺', '🟩', '🧱'],
        ['🧱', '🟩', '🍳', '🧱'],
        ['🧱', '🧱', '🧱', '🧱']
    ]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_3, game))

    end_state_test_4 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_4, game))

    # Some Moves Left, no Eggs
    empty_grid = []
    assert game.is_end_state(1, convert_to_blocks(empty_grid, game))
    assert game.is_end_state(6, convert_to_blocks(empty_grid, game))

    end_state_test_7 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪺", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    assert game.is_end_state(2, convert_to_blocks(end_state_test_7, game))

    # Egg/s in the Grid, no Moves Left
    end_state_test_8 = [["🥚"]]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_8, game))

    end_state_test_9 = [["🥚", "🥚", "🥚"]]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_9, game))

    end_state_test_10 = [
        ["🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱"]
    ]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_10, game))

    end_state_test_11 = [
        ["🍳", "🟩", "🟩"],
        ["🥚", "🥚", "🥚"]
    ]
    assert game.is_end_state(0, convert_to_blocks(end_state_test_11, game))

    # Some Moves Left, Egg(s) in the Grid
    end_state_test_12 = [["🥚"]]
    assert not game.is_end_state(
        10, convert_to_blocks(end_state_test_12, game))

    end_state_test_13 = [["🥚"]]
    assert not game.is_end_state(4, convert_to_blocks(end_state_test_13, game))

    end_state_test_14 = [
        ["🥚", "🥚", "🥚"]
    ]
    assert not game.is_end_state(
        10, convert_to_blocks(end_state_test_14, game))

    end_state_test_15 = [
        ["🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🥚", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱"]
    ]
    assert not game.is_end_state(
        10**4, convert_to_blocks(end_state_test_15, game))

    end_state_test_16 = [
        ["🍳", "🟩", "🟩"],
        ["🥚", "🥚", "🥚"]
    ]
    assert not game.is_end_state(3, convert_to_blocks(end_state_test_16, game))

    end_state_test_17 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    assert not game.is_end_state(1, convert_to_blocks(end_state_test_17, game))

    # Edge Case: Negative Moves Left (Should Return True Nevertheless)
    end_state_test_x = [["🥚"]]
    assert game.is_end_state(-1, convert_to_blocks(end_state_test_x, game))


def test_get_range() -> None:
    # Takes in a DIRECTION -> returns a RANGE
    game: Game = Game()
    get_range_test = [[]]
    game.grid = convert_to_blocks(get_range_test, game)

    game2: Game = Game()
    get_range_test_2 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    game2.grid = convert_to_blocks(get_range_test_2, game2)

    game3: Game = Game()
    get_range_test_3 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🥚", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    game3.grid = convert_to_blocks(get_range_test_3, game)

    mc1 = 0
    mc2 = 2
    mc3 = 3

    # Left and Up
    assert game.get_range(Direction.LEFT, mc1) == range(0, 0)
    assert game.get_range(Direction.FORWARD, mc1) == range(0, 0)
    assert game2.get_range(Direction.LEFT, mc2) == range(2)
    assert game2.get_range(Direction.FORWARD, mc2) == range(2)
    assert game3.get_range(Direction.LEFT, mc3) == range(3)
    assert game3.get_range(Direction.FORWARD, mc3) == range(3)

    # Right and Down
    assert game.get_range(Direction.RIGHT, mc1) == range(-1, -1, -1)
    assert game.get_range(Direction.BACKWARD, mc1) == range(-1, -1, -1)
    assert game2.get_range(Direction.RIGHT, mc2) == range(1, -1, -1)
    assert game2.get_range(Direction.BACKWARD, mc2) == range(1, -1, -1)
    assert game3.get_range(Direction.RIGHT, mc3) == range(2, -1, -1)
    assert game3.get_range(Direction.BACKWARD, mc3) == range(2, -1, -1)

    # EDGE CASES:

    # DIRECTIONS is not of type Dir
    assert not game.get_range((0, 0), mc1)
    assert not game.get_range((2, 0), mc1)
    assert not game.get_range((0, 2), mc1)
    assert not game.get_range((10, 10), mc1)
    assert not game.get_range((727, 0), mc1)
    assert not game.get_range((10**8, 10**7), mc1)
    assert not game.get_range((), mc1)
    assert not game.get_range('haha', mc1)
    assert not game.get_range([], mc1)
    assert not game.get_range({}, mc1)

    # DIRECTIONS is attribute of Dir, but they are not defined.
    with pytest.raises(AttributeError):
        assert not game.get_range(Direction.UP, mc1)
        assert not game.get_range(Direction.DOWN, mc1)
        assert not game.get_range(Direction.PASS, mc1)


def test_no_movables_left() -> None:
    # Takes in a GRID -> returns a BOOL

    g1: Game = Game()

    no_movables_test = [[]]
    g1.grid = convert_to_blocks(no_movables_test, g1)
    assert g1.no_movables_left(g1.grid)

    no_movables_test_2 = [
        ['🧱', '🧱', '🧱', '🧱'],
        ['🧱', '🟩', '🟩', '🧱'],
        ['🧱', '🟩', '🟩', '🧱'],
        ['🧱', '🧱', '🧱', '🧱']
    ]

    g2: Game = Game()

    g2.grid = convert_to_blocks(no_movables_test_2, g2)
    assert g2.no_movables_left(g2.grid)

    g3: Game = Game()

    no_movables_test_3 = [["🥚"]]
    g3.grid = convert_to_blocks(no_movables_test_3, g3)
    assert not g3.no_movables_left(g3.grid)

    g4: Game = Game()

    no_movables_test_4 = [['🥚', '🥚', '🥚']]
    g4.grid = convert_to_blocks(no_movables_test_4, g4)
    assert not g4.no_movables_left(g4.grid)

    g5: Game = Game()

    no_movables_test_5 = [
        ['🧱', '🧱', '🧱', '🧱'],
        ['🧱', '🥚', '🟩', '🧱'],
        ['🧱', '🟩', '🟩', '🧱'],
        ['🧱', '🧱', '🧱', '🧱']
    ]
    g5.grid = convert_to_blocks(no_movables_test_5, g5)
    assert not g5.no_movables_left(g5.grid)

    # Larger Examples:

    g6: Game = Game()

    no_movables_test_6 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪺", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g6.grid = convert_to_blocks(no_movables_test_6, g6)
    assert g6.no_movables_left(g6.grid)

    g7: Game = Game()
    no_movables_test_7 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g7.grid = convert_to_blocks(no_movables_test_7, g7)
    assert not g7.no_movables_left(g7.grid)

    g8 = Game()
    no_movables_test_8 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪺", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g8.grid = convert_to_blocks(no_movables_test_8, g8)
    assert g8.no_movables_left(g8.grid)

    g9 = Game()
    no_movables_test_9 = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱",
            "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🪹", "🟩", "🟩", "🍳", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🟩", "🥚", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🧱", "🧱", "🪹", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🧱",
            "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🪹",
            "🟩", "🟩", "🟩", "🟩", "🧱", "🧱", "🟩", "🟩", "🧱"],
        ["🧱", "🥚", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🥚", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🧱", "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🧱", "🧱", "🧱", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🟩", "🧱"],
        ["🧱", "🧱", "🍳", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🧱", "🟩", "🧱"],
        ["🧱", "🥚", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩", "🟩",
            "🟩", "🧱", "🧱", "🟩", "🟩", "🟩", "🧱", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🪹", "🟩", "🟩", "🍳", "🧱", "🧱", "🧱",
            "🧱", "🧱", "🧱", "🟩", "🟩", "🧱", "🧱", "🥚", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱",
            "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    g9.grid = convert_to_blocks(no_movables_test_9, g9)
    assert not g9.no_movables_left(g9.grid)

    # Using Level 1 as a Test Case:
    ga: Game = Game()
    no_movables_test_a = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    ga.grid = convert_to_blocks(no_movables_test_a, ga)
    assert not ga.no_movables_left(ga.grid)

    gb: Game = Game()
    no_movables_test_b = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🥚", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    gb.grid = convert_to_blocks(no_movables_test_b, gb)
    assert not gb.no_movables_left(gb.grid)

    gc: Game = Game()
    no_movables_test_c = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🥚", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    gc.grid = convert_to_blocks(no_movables_test_c, gc)
    assert not gc.no_movables_left(gc.grid)

    gd = Game()
    no_movables_test_d = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🥚", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    gd.grid = convert_to_blocks(no_movables_test_d, gd)
    assert not gd.no_movables_left(gd.grid)

    ge: Game = Game()
    no_movables_test_e = [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]
    ge.grid = convert_to_blocks(no_movables_test_e, ge)
    assert ge.no_movables_left(ge.grid)

    # MOCK FUNCTION/S FOR TESTING

    # Not really sure if randint is the best for the purpose of testing with random values.


def inbound(n: int) -> int:
    # For is_inside_test.is_inside, returns an INT inside the bounds of rows or cols.
    return randint(0, n - 1)


def outbound(n: int) -> int:
    # For is_inside_test.is_inside, returns an INT outside the bounds of rows or cols.
    rand_extra = randint(n, 10**7)
    rand_below = randint(-10**7, -1)

    return choice([rand_extra, rand_below])
