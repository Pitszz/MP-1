import pytest
from game import Game, DisplayManager, Block, Level
from utils import Direction, BlockType, Sprite


# The methods with no return or yielded values are NOT unit tested.
# Exceptions are some methods in the Block class.
# Inner functions are also not unit tested.

# CORE LOGIC TESTS


class MockGame(Game):
    # a subclass to make testing easier
    def __init__(self, grid: list[list[str]], moves=0):
        super().__init__()
        self.grid = convert_to_blocks(grid, self)
        self.movables_positions = self.level.get_movables_positions(
            self.grid)
        self.movables_index = []

    def _process_move(self, direction: Direction) -> None:
        for x in self.get_range(direction, movables_count=2):
            i, j = self.movables_positions[x]
            block: Block = self.grid[i][j]
            assert block.type == BlockType.MOVABLE
            block.move(self, self.score_manager, 1, direction, x)

    def get_grid(self) -> list[list[str]]:
        return [[block.sprite for block in row]
                for row in self.grid]


def convert_to_blocks(grid: list[list[str]], game: Game) -> list[list[Block]]:
    result = []

    for i in range(len(grid)):
        temp = []
        for j in range(len(grid[0])):
            block = game.level._create_block(grid[i][j], i, j)
            temp.append(block)
        result.append(temp)

    return result


def test_move() -> None:
    # Given a DIRECTION, change the position of MOVABLES

    # TEST CASE 1
    move_test_a = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ])

    # Going Left
    move_test_a._process_move(Direction.LEFT)

    assert move_test_a.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪺", "🟩", "🍳", "🧱"],
        ["🧱", "🪺", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    # Going Right
    move_test_b = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ])
    move_test_b._process_move(Direction.RIGHT)

    assert move_test_b.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🟩", "🍳", "🧱"],
        ["🧱", "🪹", "🟩", "🥚", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    # Going Forward
    move_test_c = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ])
    move_test_c._process_move(Direction.FORWARD)

    assert move_test_c.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🟩", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    # Going Backward
    move_test_d = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ])
    move_test_d._process_move(Direction.BACKWARD)

    assert move_test_d.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    # TEST CASE 2
    move_test_2a = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ])

    # Going Left
    move_test_2a._process_move(Direction.LEFT)

    assert move_test_2a.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🥚", "🥚", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    move_test_2b = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ])
    move_test_2b._process_move(Direction.RIGHT)

    assert move_test_2b.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    move_test_2c = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ])

    move_test_2c._process_move(Direction.FORWARD)

    assert move_test_2c.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    move_test_2d = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🥚", "🥚", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🟩", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ])
    move_test_2d._process_move(Direction.BACKWARD)

    assert move_test_2d.get_grid() == [
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🪹", "🪹", "🟩", "🟩", "🟩", "🟩", "🧱"],
        ["🧱", "🟩", "🟩", "🟩", "🟩", "🥚", "🍳", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱", "🧱"]
    ]

    # EDGE CASE: Undefined Direction
    move_test_y = MockGame([
        ["🧱", "🧱", "🧱", "🧱", "🧱"],
        ["🧱", "🟩", "🍳", "🟩", "🧱"],
        ["🧱", "🪹", "🥚", "🍳", "🧱"],
        ["🧱", "🪹", "🥚", "🟩", "🧱"],
        ["🧱", "🧱", "🧱", "🧱", "🧱"]
    ])

    with pytest.raises(AttributeError):
        move_test_y._process_move(Direction.NULL)
        move_test_y._process_move(Direction.FLAG)
        move_test_y._process_move(Direction.WRONG)


def test_on_collision() -> None:
    # Tests if MOVABLE at a given index can move onto neighbor

    # Test Cases: using a new instance of mock_collision every time

    # FLOOR Collision
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    floor_collision = collision_test._create_block("🥚", 0, 0)
    neighbor_floor = collision_test._create_block("🟩", 0, 1)
    assert neighbor_floor.type.name == BlockType.FLOOR.name

    nr = floor_collision.row + neighbor_floor.row
    nc = floor_collision.col + neighbor_floor.col
    floor_collision._on_collision(
        game, game.score_manager, nr, nc, neighbor_floor, 1, 0)
    assert floor_collision.sprite == "🟩"
    assert neighbor_floor.sprite == "🥚"

    # VOID Collision
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    void_collision = collision_test._create_block("🥚", 0, 0)
    neighbor_void = collision_test._create_block("🍳", 1, 0)
    assert neighbor_void.type.name == BlockType.VOID.name

    nr = void_collision.row + neighbor_void.row
    nc = void_collision.col + neighbor_void.col
    void_collision._on_collision(
        game, game.score_manager, nr, nc, neighbor_void, 1, 0)
    assert void_collision.sprite == "🟩"
    assert neighbor_void.sprite == "🍳"
    assert game.score_manager.get_score() == -5

    # GOAL Collision
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    goal_collision = collision_test._create_block("🥚", 0, 0)
    neighbor_goal = collision_test._create_block("🪹", -1, 0)
    assert neighbor_goal.type.name == BlockType.GOAL.name

    nr = goal_collision.row + neighbor_goal.row
    nc = goal_collision.col + neighbor_goal.col
    goal_collision._on_collision(
        game, game.score_manager, nr, nc, neighbor_goal, 1, 0)
    assert goal_collision.sprite == "🟩"
    assert neighbor_goal.sprite == "🪺"
    assert game.score_manager.get_score() == 10 + 1  # current move counted

    # MOVABLE OR IMMOVABLE Collision (they act the same)
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    move_collision = collision_test._create_block("🥚", 0, 0)
    neighbor_move = collision_test._create_block("🥚", 0, -1)
    assert neighbor_move.type.name == BlockType.MOVABLE.name

    # nothing happens
    neighbor_move._on_collision(
        game, game.score_manager, nr, nc, neighbor_move, 1, 0)
    assert move_collision.sprite == "🥚"
    assert neighbor_move.sprite == "🥚"

    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    nomove_collision = collision_test._create_block("🥚", 0, 0)
    neighbor_nomove = collision_test._create_block("🧱", 0, -1)
    assert neighbor_nomove.type.name == BlockType.IMMOVABLE.name

    # nothing happens
    nomove_collision._on_collision(
        game, game.score_manager, nr, nc, neighbor_nomove, 1, 0)
    assert nomove_collision.sprite == "🥚"
    assert neighbor_nomove.sprite == "🧱"

    # EDGE CASE: Block passed is not Movable, raise AssertionError
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    x_collision = collision_test._create_block("🧱", 0, 0)
    neighbor_x = collision_test._create_block("🟩", 0, 1)
    assert neighbor_x.type.name == BlockType.FLOOR.name

    nr = x_collision.row + neighbor_x.row
    nc = x_collision.col + neighbor_x.col
    with pytest.raises(AssertionError):
        x_collision._on_collision(
            game, game.score_manager, nr, nc, neighbor_x, 1, 0)

    # EDGE CASE: Neighbor doesn't exist
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    y_collision = collision_test._create_block("🧱", 0, 0,)
    with pytest.raises(NameError):
        y_collision._on_collision(
            game, game.score_manager, nr, nc, neighbor_y, 1, 0)

    # EDGE CASE: Block doesn't exist but neighbor does
    game: Game = Game()
    collision_test = game.level
    game.movables_positions = [(0, 0)]
    game.movables_index = []

    neighbor_z = collision_test._create_block("🪹", -1, 0)
    with pytest.raises(NameError):
        z_collision._on_collision(
            game, game.score_manager, nr, nc, neighbor_z, 1, 0)


def test_create_block() -> None:
    # Tests if Block object is Initialized Properly
    create_block_test = Level()

    # Normal Blocks, BlockType.name comparison
    block_egg = create_block_test._create_block("🥚", 0, 0)
    assert block_egg.type.name == BlockType.MOVABLE.name
    assert block_egg.name == "Egg"
    assert block_egg.sprite == "🥚"

    block_grass = create_block_test._create_block("🟩", 0, 0)
    assert block_grass.type.name == BlockType.FLOOR.name
    assert block_grass.name == "Grass"
    assert block_grass.sprite == "🟩"

    block_wall = create_block_test._create_block("🧱", 0, 0)
    assert block_wall.type.name == BlockType.IMMOVABLE.name
    assert block_wall.name == "Wall"
    assert block_wall.sprite == "🧱"

    block_nest = create_block_test._create_block("🪹", 0, 0)
    assert block_nest.type.name == BlockType.GOAL.name
    assert block_nest.name == "Nest"
    assert block_nest.sprite == "🪹"

    block_full = create_block_test._create_block("🪺", 0, 0)
    assert block_full.type.name == BlockType.IMMOVABLE.name
    assert block_full.name == "Full Nest"
    assert block_full.sprite == "🪺"

    block_pan = create_block_test._create_block("🍳", 0, 0)
    assert block_pan.type.name == BlockType.VOID.name
    assert block_pan.name == "Pan"
    assert block_pan.sprite == "🍳"

    block_hole = create_block_test._create_block(" ", 0, 0)
    assert block_hole.type.name == BlockType.VOID.name
    assert block_hole.name == "Hole"
    assert block_hole.sprite == " "

    # Wrong Assertions
    block_egg = create_block_test._create_block("🥚", 0, 0)
    assert not block_egg.type.name == BlockType.IMMOVABLE.name
    assert not block_egg.name == "Pan"
    assert not block_egg.sprite == "🟩"

    # EDGE CASE: sprite is not passed or unrecognized
    with pytest.raises(KeyError):
        assert create_block_test._create_block("", 0, 0)
        assert create_block_test._create_block("A", 0, 0)
        assert create_block_test._create_block((0, 1), 0, 0)
        assert create_block_test._create_block(12, 0, 0)


def test_change_block_to() -> None:
    # Given a Sprite, Tests if Block is Changed Correctly
    mock_create_block = Level()

    # Normal Case (any block can work as long as it is defined)

    block_test = mock_create_block._create_block("🥚", 0, 0)

    block_test._change_block_to(Sprite.GRASS)
    assert block_test.sprite == "🟩"
    assert block_test.name == "Grass"
    assert block_test.type.name == BlockType.FLOOR.name

    block_test._change_block_to(Sprite.WALL)
    assert block_test.sprite == "🧱"
    assert block_test.name == "Wall"
    assert block_test.type.name == BlockType.IMMOVABLE.name

    block_test._change_block_to(Sprite.NEST)
    assert block_test.sprite == "🪹"
    assert block_test.name == "Nest"
    assert block_test.type.name == BlockType.GOAL.name

    block_test._change_block_to(Sprite.FULL_NEST)
    assert block_test.sprite == "🪺"
    assert block_test.name == "Full Nest"
    assert block_test.type.name == BlockType.IMMOVABLE.name

    block_test._change_block_to(Sprite.PAN)
    assert block_test.sprite == "🍳"
    assert block_test.name == "Pan"
    assert block_test.type.name == BlockType.VOID.name

    block_test._change_block_to(Sprite.HOLE)
    assert block_test.sprite == " "
    assert block_test.name == "Hole"
    assert block_test.type.name == BlockType.VOID.name

    block_test._change_block_to(Sprite.EGG)
    assert block_test.sprite == "🥚"
    assert block_test.name == "Egg"
    assert block_test.type.name == BlockType.MOVABLE.name

    # EDGE CASE: Unrecognized Sprite Passed, raise AttributeError

    block_x = mock_create_block._create_block("🥚", 0, 0)

    with pytest.raises(AttributeError):
        assert block_x._change_block_to(Sprite.NULL)
        assert block_x._change_block_to(Sprite.BRUH)
        assert block_x._change_block_to(Sprite.FLAG)
        assert block_x._change_block_to(Sprite.UGANDA)
        assert block_x._change_block_to(Sprite.KNUCKLES)


def test_delete() -> None:
    # Tests if Block is Converted to a FLOOR Block
    mock_delete: Game = Game()
    sm = mock_delete.score_manager

    # Normal Cases, even if unusual besides Egg
    delete_egg = mock_delete.level._create_block("🥚", 0, 0)
    delete_wall = mock_delete.level._create_block("🧱", 0, 0)
    delete_grass = mock_delete.level._create_block("🟩", 0, 0)
    delete_nest = mock_delete.level._create_block("🪹", 0, 0)
    delete_full = mock_delete.level._create_block("🪺", 0, 0)
    delete_pan = mock_delete.level._create_block("🍳", 0, 0)
    delete_hole = mock_delete.level._create_block(" ", 0, 0)

    delete_egg._delete(sm)
    assert delete_egg.sprite == "🟩"
    assert delete_egg.name == "Grass"
    assert delete_egg.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    delete_wall._delete(sm)
    assert delete_wall.sprite == "🟩"
    assert delete_wall.name == "Grass"
    assert delete_wall.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    delete_grass._delete(sm)
    assert delete_grass.sprite == "🟩"
    assert delete_grass.name == "Grass"
    assert delete_grass.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    delete_nest._delete(sm)
    assert delete_nest.sprite == "🟩"
    assert delete_nest.name == "Grass"
    assert delete_nest.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    delete_full._delete(sm)
    assert delete_full.sprite == "🟩"
    assert delete_full.name == "Grass"
    assert delete_full.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    delete_pan._delete(sm)
    assert delete_pan.sprite == "🟩"
    assert delete_pan.name == "Grass"
    assert delete_pan.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    delete_hole._delete(sm)
    assert delete_hole.sprite == "🟩"
    assert delete_hole.name == "Grass"
    assert delete_hole.type.name == "FLOOR"
    assert sm.get_score() == -5

    sm.set_score(0)  # Reset Score

    # EDGE CASE: Block does not exist in the first place

    with pytest.raises(NameError):
        assert delete_null._delete(sm)
        assert delete_what._delete(sm)
        assert delete_itworks._delete(sm)
