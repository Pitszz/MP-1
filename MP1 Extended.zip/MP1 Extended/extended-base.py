import os
import sys
import time
import subprocess

from utils import Direction, BlockType, Sprite, Config, BLOCK_MAP, DIRECTION_MAP, ARROW_MAP
from typing import Self


class Game:
    def __init__(self, filename: str):
        self.level_data = Level(self, filename)
        self.display_manager = DisplayManager(self)

        self.score = 0
        self.grid = self.level_data.grid
        self.moves = self.level_data.max_moves
        self.current_move = ""
        self.previous_moves = []

    def play(self):
        while not self.is_end_state():
            self.display_manager.display()

            player_input = input("Enter direction: ").strip().lower()

            if player_input == "Q":
                break
            elif player_input in DIRECTION_MAP:
                self.current_move = DIRECTION_MAP[player_input]
                self.previous_moves.append(player_input)
                self.moves -= 1
                self.process_move(self.current_move)
            else:
                print("Invalid Move")

    def process_move(self, direction: Direction):
        rows = self.level_data.rows
        cols = self.level_data.cols
        range_rows, range_cols = self.get_range(rows, cols, direction)

        while not self.all_objects_blocked(rows, cols, direction):
            for row in range_rows:
                for col in range_cols:
                    block = self.grid[row][col]
                    if block._type == BlockType.MOVABLE:
                        block.move(direction)

            self.display_manager.display()
            time.sleep(Config.MOVE_DELAY)

    def get_range(self, rows: int, cols: int, direction: Direction) -> tuple[range, range]:
        if direction in (Direction.FORWARD, Direction.LEFT):
            return range(rows), range(cols)

        elif direction in (Direction.BACKWARD, Direction.RIGHT):
            return range(rows - 1, -1, -1), range(cols - 1, -1, -1)

    def is_end_state(self) -> bool:
        return self.moves <= 0 or self.no_movables_left()

    def all_objects_blocked(self, rows, cols, direction: Direction) -> bool:
        for row in range(rows):
            for col in range(cols):
                block = self.grid[row][col]
                if block._type == BlockType.MOVABLE:
                    (new_row, new_col) = direction.value
                    new_row += row
                    new_col += col

                    if 0 <= new_row < rows and 0 <= new_col < cols:
                        neighbor = self.grid[new_row][new_col]
                        if neighbor._type in (BlockType.FLOOR, BlockType.VOID) or neighbor.sprite == Sprite.NEST:
                            return False

        return True

    def no_movables_left(self) -> bool:
        for row in self.grid:
            for block in row:
                if block._type == BlockType.MOVABLE:
                    return False

        return True


class DisplayManager:
    def __init__(self, game: Game):
        self.game = game

    def display(self):
        self.display_level()
        self.display_status()

    def display_level(self):
        self.clear_screen()
        grid = self.game.grid

        for row in grid:
            print("".join(block.sprite for block in row))

    def display_status(self) -> None:
        print(f"Score: {self.game.score}")
        print(f"Moves: {
              self.game.moves}/{self.game.level_data.max_moves}")
        print(f"Previous Moves: {
              self.convert_moves_to_arrows(self.game.previous_moves)}")

    def clear_screen(self) -> None:
        if sys.stdout.isatty():
            clear_cmd = "cls" if os.name == "nt" else "clear"
            subprocess.run([clear_cmd], shell=True)

    def convert_moves_to_arrows(self, previous_moves: list[str], max_length: int = 20) -> str:
        converted = "".join([ARROW_MAP[move]
                            for move in previous_moves[-max_length:]])

        if len(previous_moves) > max_length:
            return "..." + converted
        else:
            return converted


class Block:
    def __init__(self, name: str, sprite: str, _type: BlockType, row: int, col: int, game: Game):
        self.game = game
        self.name = name
        self.sprite = sprite
        self._type = _type
        self.row = row
        self.col = col

    def move(self, direction: Direction):
        (row, col) = direction.value
        new_row = self.row + row
        new_col = self.col + col

        if 0 <= new_row < self.game.level_data.rows and 0 <= new_col < self.game.level_data.cols:
            self.on_collision(self.game.grid[new_row][new_col])

    def on_collision(self, neighbor: Self):
        assert self._type == BlockType.MOVABLE
        # print("Yes i am egg")
        # print("Neighbor type is", neighbor._type)

        if neighbor._type == BlockType.MOVABLE:
            if neighbor.sprite == Sprite.EGG:
                pass

        elif neighbor._type == BlockType.FLOOR:
            neighbor._change_block_to(Sprite.EGG)
            self._change_block_to(Sprite.GRASS)

        elif neighbor._type == BlockType.IMMOVABLE:
            if neighbor.sprite == Sprite.NEST:
                neighbor._change_block_to(Sprite.FULL_NEST)
                self._change_block_to(Sprite.GRASS)
                self.game.score += Config.ADD_SCORE + self.game.moves + 1

        elif neighbor._type == BlockType.VOID:
            self._delete()

    def _delete(self):
        self._change_block_to(Sprite.GRASS)
        self.game.score += Config.SUBSTRACT_SCORE

    def _change_block_to(self, sprite: str):
        (name, block_type) = BLOCK_MAP[sprite]

        # print(f"Changing {repr(self.name)} block to", name)

        self.sprite = sprite
        self.name = name
        self._type = block_type


class Level:
    def __init__(self, game: Game, filename: str, folder: str = "levels"):
        self.grid = []
        self.rows = 0
        self.cols = 0
        self.max_moves = 0

        self.game = game
        self._load_level(filename, folder)

    def _load_level(self, filename: str, folder: str) -> None:
        file_path = os.path.join(folder, filename)

        try:
            with open(file_path, "r", encoding="utf-8") as file:
                self.rows = int(file.readline())
                self.max_moves = int(file.readline())

                for row in range(self.rows):
                    line = file.readline().strip()
                    grid_row = [
                        self._create_block(char, row, col, self.game) for (col, char) in enumerate(line)
                    ]
                    self.grid.append(grid_row)

                self.cols = len(self.grid[0])

        except FileNotFoundError:
            print(f"File {filename} not found")
            sys.exit()

    def _create_block(self, char: str, row: int, col: int, game: Game) -> Block:
        (name, block_type) = BLOCK_MAP[char]

        return Block(name, char, block_type, row, col, self.game)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("The game requires a level file to run.")
        sys.exit()

    filename = sys.argv[1]
    game = Game(filename)
    game.play()
